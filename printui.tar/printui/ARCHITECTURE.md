# PrintUI AEM

The PrintUI AEM Bundle of Java Service Components and Servlets contains the following classes and templates:

| Module   	       	       	          | Purpose | Description |
| -------------------------- | ----- | ----- |
|./ClientInfoService.java 		  | api | Client Configuration Template |
|./CloseJobService.java 		  | api | Close Job Template |
|./Configuration.java 			  | cfg | Client Configuration |
|./ConfigurationService.java 		  | cfg | Client Configuration Service Template |
|./ConfigurationServiceImpl.java 	  | cfg | Client COnfiguration Service Cache |
|./DeleteJobService.java 		  | api | Delete Job Template |
|./GetPdfService.java 			  | api | Get PDF Template |
|./GetPreviewService.java 		  | api | Get Preview Template |
|./HelloService.java 			  | test | Template |
|./ListAllTemplatesService.java 	  | api | List All Templates Service Template |
|./ListTemplatesDetailsService.java 	  | api | List Templates Details Service Template |
|./ListTemplatesService.java 		  | api | List Templates Service Template |
|./NewJobService.java 			  | api | New Job Template |
|./OpenJobService.java 			  | api | Open Job Template |
|./PrintUIClient.java 			  | X | Attempt at Factory COnfiguration |
|./PrintUIClientFactory.java 		  | http | Template for HTTP requests |
|./PrintUIService.java 			  | http | Template for HTTP interactions with PrintUI APIs |
|./RepImageService.java			  | api | Rep Image Service Template |
|./RequestPdfService.java 		  | api | Request PDF Service Template |
|./RequestPreviewService.java 		  | api | Request Preview Service Template |
|./TestService.java 			  | test | Test Service Template |
|./api/ClientInfo.java 			  | api | Cient Configuration (XML) |
|./api/CloseJob.java 			  | api | Close Job (Status) |
|./api/DeleteJob.java 			  | api | Delete Job (Status) |
|./api/GetPdf.java 			  | api | Get requested PDF (XML) |
|./api/GetPreview.java 			  | api | Get requested Preview (XML) |
|./api/ListAllTemplates.java 		  | api | List All Templates (XML) |
|./api/ListTemplates.java 		  | api | List Templates (XML) |
|./api/ListTemplatesDetails.java 	  | api | List Templates Details (XML) |
|./api/NewJob.java 			  | api | New Job (String) |
|./api/OpenJob.java 			  | api | Open Job (Status) |
|./api/RepImage.java 			  | api | Rep Image for Template (XML) |
|./api/RequestPdf.java 			  | api | Request PDF (Stream) |
|./api/RequestPreview.java 		  | api | Request Preview (Stream) |
|./impl/HelloServiceImpl.java 		  | test | Bundle test |
|./impl/PrintUIClientAPI.java 		  | http | HTTP interactions with PrintUI APIs |
|./impl/PrintUIClientAdmin.java 	  | X | Attempt at Factory Configuration |
|./impl/PrintUIClientImpl.java 		  | X | Attempt at Factory Configuration |
|./impl/TestServiceImpl.java 		  | test | Test Service |
|./impl/filters/LoggingFilter.java 	  | test | Logging filter - unused |
|./json/AbstractJSONObjectVisitor.java 	  | test | Test class |
|./json/JcrJsonAdapter.java 		  | test | Test class (so far) |

## PrintUI HTTP
Handle all HTTP to PrintUI Servers

### Classes
- PrintUIService - template for all HTTP APIs
- PrintUIClientFactory - template for HTTP requests
- PrintUIClientAPI - implementation for HTTP requests

## PrintUI Configuration
Saved internally as needed by authid
Assumes https://admin.w2p-tools.com/api/getclientinfo.php for all clientInfo.

### Classes
- Configuration
- ConfigurationServiceImpl
- ClientInfo

### Data
- authid - authorization id
- client - client name
- adminUrl - url to admin for client
- idsUrl - url to indesign server for client

# JSP Pages
There are three pages defined for the PrintUI Site.

1. Choose PrintUI Template
2. Edit PrintUI Job
3. Save PrintUI Job to AEM Assets 

## Choose PrintUI Template
Choose Template (Page JSP)

### Classes
- DeleteJob (do we delete job? do we do derivative?)
- ListTemplateDetails
- ListAllTemplates
- ListTemplates

## Edit PrintUI Job
Edit Job using HTML5 PrintUI Editor (Page JSP)

- iframe (do we need crosssite xml?)
- Cancel returns to Choose PrintUI Template Page
- Finished goes to Save PrintUI Job Page

### Classes
- NewJob
- Configuration
- ConfigurationServiceImpl

## Save PrintUI Job
Save Job to AEM Assets (Page JSP - Form)

### Form:
- Edit Button - returns to edit job
- Cancel Button - returns to choose template
- Save Button - invokes SaveAssetServlet
- Choose Type - either PDF or JPG
- Title - the Title for the output
- Dest Path - the path in the AEM Assets
- Save Job - checkbox for saving Job for up to one year.
- JobID - hidden job-id
- Template - hidden template name

### Classes
- OpenJob
- CloseJob

# Sling Servlets

## Get Preview Servlet (GET /bin/printui/getpreview.jpg)
Create and retrieve lower res jpg image to show on page.

### Classes
- RequestPreview
- GetPreview

### Returns
jpg stream

## Save Asset Servlet (POST /bin/printui/saveasset)
Create, retrieve and save high res jpg or pdf into AEM Assets

### Classes
- RequestPreview
- RequestPdf
- GetPreview
- GetPdf
- DeleteJob
- CloseJob

### Logic
```
If jpg {
   RequestPreview
   GetPreview
}
If pdf {
   RequestPdf
   GetPdf
}
Save Asset
If no job save {
   DeleteJob
}
If job save {
   CloseJob
   Save Asset metadata
}
```

### Returns
URL for redirection
