package com.printui;

import java.io.InputStream;

public interface AssetActionsService {

    public InputStream requestAndGetPreview(String auth, String job, String resolution, String type);

    public InputStream requestAndGetPdf(String auth, String job);

}
