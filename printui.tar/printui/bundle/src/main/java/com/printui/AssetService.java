package com.printui;

import org.w3c.dom.Document;

import org.apache.sling.api.resource.ResourceResolver; 

import org.apache.sling.commons.json.JSONObject;

import java.io.InputStream;

/**
 * A simple service interface
 */
public interface AssetService {

    public long execute(final ResourceResolver resolver,final String path, final String query, int offset, int size);
    
    public JSONObject getResultsAsJSON(int offset, int size);

    public Document getResultsAsXML(int offset, int size);

    public JSONObject create(final ResourceResolver resolver,final String path, final String filename, final String mimetype, final String collection, final String version, InputStream stream);

    public JSONObject newFolder(final ResourceResolver resolver,final String path, final String foldername);
}
