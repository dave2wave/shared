package com.printui;

import com.printui.Configuration;

public interface ClientInfoService {

    public String getInfo(String val); 

    public Configuration getConfiguration(Configuration c);
}
