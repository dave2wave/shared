package com.printui;

public interface CloseJobService {

    public boolean closeJob(String auth, String jobid); 

}
