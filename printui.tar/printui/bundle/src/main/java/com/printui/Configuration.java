package com.printui;

public class Configuration {

    String auth;
    String client;
    String adminUrl;
    String idsUrl;

    Configuration( String myAuth ) {
	auth = myAuth;
	client = null;
	adminUrl = null;
	idsUrl = null;
    }

    public String getAuth() {
	return auth;
    }
    
    public String getClient() {
	return client;
    }
    
    public String getAdminUrl() {
	return adminUrl;
    }

    public String getIdsUrl() {
	return idsUrl;
    }

    public void setClient(String myClient) {
	client = myClient;
    }

    public void setAdminUrl(String myAdminUrl) {
	adminUrl = myAdminUrl;
    }

    public void setIdsUrl(String myIdsUrl) {
	idsUrl = myIdsUrl;
    }
}
