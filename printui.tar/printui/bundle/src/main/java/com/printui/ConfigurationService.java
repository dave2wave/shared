package com.printui;

import com.printui.Configuration;

public interface ConfigurationService {
    
    public Configuration SaveConfiguration( String myAuth );

    public Configuration GetConfiguration( String myAuth );

}
