package com.printui;

import com.printui.Configuration;
import com.printui.ConfigurationService;
import com.printui.api.ClientInfo;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

import java.util.concurrent.ConcurrentHashMap;

@Component
@Service
public class ConfigurationServiceImpl implements ConfigurationService {

    private static final ConcurrentHashMap<String,Configuration> conHashMap = new ConcurrentHashMap<String,Configuration>();

    @Override
    public Configuration SaveConfiguration( String myAuth ) {
	Configuration c = new Configuration(myAuth);
	ClientInfo ci = new ClientInfo();
	c = ci.getConfiguration(c);
	conHashMap.put( myAuth, c );
	return c;
    }

    @Override
    public Configuration GetConfiguration( String myAuth ) {
	Configuration c = conHashMap.get( myAuth );
	if ( c == null ) {
	    c = SaveConfiguration( myAuth );
	}
	return c;
    }
}
