package com.printui;

import org.w3c.dom.Document;

import com.adobe.granite.rest.utils.DeepModifiableValueMapDecorator;

import org.apache.sling.api.resource.ResourceResolver; 

import org.apache.sling.commons.json.JSONObject;

/**
 * A simple service interface
 */
public interface DataService {
    
    public DeepModifiableValueMapDecorator getData(final ResourceResolver resourceResolver, final String path);

    public JSONObject getDataAsJSON(final ResourceResolver resourceResolver, final String path);

    public Document getDataAsXML(final ResourceResolver resourceResolver, final String path);
    
}
