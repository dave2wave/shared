package com.printui;

public interface DeleteJobService {

    public boolean deleteJob(String auth, String jobid); 

}
