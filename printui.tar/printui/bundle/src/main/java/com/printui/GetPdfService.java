package com.printui;

import java.io.InputStream;

public interface GetPdfService {

    public InputStream getPdf(String auth,String jobid,String loc,long timeout); 

}
