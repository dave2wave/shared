package com.printui;

import java.io.InputStream;

public interface GetPreviewService {

    public InputStream getPreview(String auth,String jobid,String loc,long timeout); 

}
