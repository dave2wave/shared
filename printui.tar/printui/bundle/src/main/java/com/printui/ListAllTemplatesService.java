package com.printui;

public interface ListAllTemplatesService {

    public String getList(String auth, String include ); 

}
