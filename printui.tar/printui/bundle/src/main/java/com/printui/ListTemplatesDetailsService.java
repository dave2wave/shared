package com.printui;

import org.w3c.dom.Document;

public interface ListTemplatesDetailsService {

    public Document getDetails(String val); 

}
