package com.printui;

public interface ListTemplatesService {

    public String getList(String val); 

}
