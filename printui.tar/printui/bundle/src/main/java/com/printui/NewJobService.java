package com.printui;

public interface NewJobService {

    public String newJob(String auth, String t, String n); 

}
