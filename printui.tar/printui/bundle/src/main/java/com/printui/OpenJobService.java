package com.printui;

public interface OpenJobService {

    public boolean openJob(String auth, String jobid); 

}
