package com.printui;

import com.printui.impl.PrintUIClientAPI;

//import org.osgi.annotation.versioning.ProviderType;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.lang.Thread;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.NameValuePair;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.fluent.Content;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//@ProviderType
public interface PrintUIService {

    static final Logger log = LoggerFactory.getLogger(PrintUIService.class);

    // PrintUIService interface
    InputStream getStream(String params,long timeout);
    
    String getString(String params);

    Document getXML(String params);

    int getStatus(String params);

    // Fluent HTTP

    // return HTTP response as a String
    default String postForString(String url, String api, String params) {
	String info = "ERROR";
	PrintUIClientAPI printUIClientAPI = null;
	try {
	    printUIClientAPI = activate(url);
	    log.info("params: "+params);
	    //Request request = printUIClientAPI.post(api+"?"+params);
	    Request request = printUIClientAPI.post(api).bodyForm(URLEncodedUtils.parse(params,StandardCharsets.UTF_8));
	    info = printUIClientAPI.getExecutor().execute(request).returnContent().asString();
	    log.info(info);
	} catch (Exception e) {
	    log.error("error with post", e);
	} finally {
	    deactivate(printUIClientAPI);
	}
	return info;
    }

    // return HTTP status code
    default int postForStatus(String url, String api, String params) {
	int status = 404;
	PrintUIClientAPI printUIClientAPI = null;
	try {
	    printUIClientAPI = activate(url);
	    log.info("auth: "+params);
	    //Request request = printUIClientAPI.post(api+"?"+params);
	    Request request = printUIClientAPI.post(api).bodyForm(URLEncodedUtils.parse(params,StandardCharsets.UTF_8));
	    final HttpResponse response = printUIClientAPI.getExecutor().execute(request).returnResponse();
	    StatusLine statusLine = response.getStatusLine();
	    status = statusLine.getStatusCode();
	    log.info("retrieve status = "+status);
	} catch (Exception e) {
	    log.error("error with post", e);
	} finally {
	    deactivate(printUIClientAPI);
	}
	return status;
    }
    
    // return HTTP response as a Stream of bytes
    default InputStream postForStream(String url, String api, String params, long timeout) {
	InputStream data = null;
	PrintUIClientAPI printUIClientAPI = null;
	try {
	    printUIClientAPI = activate(url);
	    log.info("url: "+url+"params: "+params);
	    long wait = 0L;
	    int status = 404;
	    long sleepFor = 1000L;
	    long timer = timeout*sleepFor;
	    do {
		Thread.sleep(sleepFor);
		//Request request = printUIClientAPI.post(api+"?"+params);
		Request request = printUIClientAPI.post(api).bodyForm(URLEncodedUtils.parse(params,StandardCharsets.UTF_8));
		final HttpResponse response = printUIClientAPI.getExecutor().execute(request).returnResponse();
		StatusLine statusLine = response.getStatusLine();
		status = statusLine.getStatusCode();
		sleepFor = 1000L;
		if ( status == 200 ) {
		    final HttpEntity entity = response.getEntity();
		    data = entity.getContent();
		    log.info("200 - received InputStream");
		    return data;
		} else if ( status == 202 ) {
		    log.info(status+" - received");
		    Document doc = handleXMLResponse(response);
		    Element elem = doc.getDocumentElement();
		    /// code 3 and wait processing
		    String code = getString("code",elem);
		    log.info("code = "+code);
		    if ( !"3".equals(code) ) return null;
		} else {
		    log.info(status+" - received");
		    return null;
		}
		wait += sleepFor;
		log.info("202 - received - wait = "+wait+"; sleep = "+sleepFor+"; timer = "+timer);
	    } while (wait<timer);
	    log.info(status+" - received");
	} catch (Exception e) {
	    log.error("error with post", e);
	} finally {
	    deactivate(printUIClientAPI);
	}
	return data;
    }

    // return HTTP response as an XML DOM.
    default Document postForXML(String url, String api,String params) {
	Document doc = null;
	PrintUIClientAPI printUIClientAPI = null;
	try {
	    printUIClientAPI = activate(url);
	    log.info("auth: "+params);
	    //Request request = printUIClientAPI.post(api+"?"+params);
	    Request request = printUIClientAPI.post(api).bodyForm(URLEncodedUtils.parse(params,StandardCharsets.UTF_8));
	    final HttpResponse response = printUIClientAPI.getExecutor().execute(request).returnResponse();
	    doc = handleXMLResponse(response);
	    log.info("retrieve xml doc");
	} catch (Exception e) {
	    log.error("error with post", e);
	} finally {
	    deactivate(printUIClientAPI);
	}
	return doc;
    }

    default PrintUIClientAPI activate(String url) throws Exception {
	PrintUIClientAPI clientAPI = new PrintUIClientAPI();
	clientAPI.activate(url);
	return clientAPI;
    }

    default void deactivate(PrintUIClientAPI clientAPI) {
	if (clientAPI != null) {
	    clientAPI.deactivate();
	}
    }

    default Document handleXMLResponse(final HttpResponse response) throws IOException {
	StatusLine statusLine = response.getStatusLine();
	HttpEntity entity = response.getEntity();
	if (statusLine.getStatusCode() >= 300) {
	    throw new HttpResponseException(
					    statusLine.getStatusCode(),
					    statusLine.getReasonPhrase());
	}
	if (entity == null) {
	    throw new ClientProtocolException("Response contains no content");
	}
	log.info("xml entity: "+EntityUtils.toString(entity));
	DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
	try {
	    DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
	    ContentType contentType = ContentType.getOrDefault(entity);
	    //if (!contentType.equals(ContentType.APPLICATION_XML)) {
	    //	throw new ClientProtocolException("Unexpected content type:" + contentType);
	    //}
	    Charset charset = contentType.getCharset();
	    if (charset == null) {
		charset = Consts.ISO_8859_1;
	    }
	    return docBuilder.parse(entity.getContent(), charset.name());
	} catch (ParserConfigurationException ex) {
	    throw new IllegalStateException(ex);
	} catch (SAXException ex) {
	    throw new ClientProtocolException("Malformed XML document", ex);
	}
    }

    default String getString(String tagName, Element element) {
        NodeList list = element.getElementsByTagName(tagName);
        if (list != null && list.getLength() > 0) {
            NodeList subList = list.item(0).getChildNodes();

            if (subList != null && subList.getLength() > 0) {
                return subList.item(0).getNodeValue();
            }
        }
        return null;
    }
}
