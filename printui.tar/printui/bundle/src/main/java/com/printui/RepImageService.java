package com.printui;

public interface RepImageService {

    public String getThumbnail(String auth, String t, String n); 

}
