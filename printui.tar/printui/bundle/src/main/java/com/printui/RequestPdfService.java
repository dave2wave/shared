package com.printui;

import org.w3c.dom.Document;

public interface RequestPdfService {

    public Document requestPdf(String auth,String jobid); 

}
