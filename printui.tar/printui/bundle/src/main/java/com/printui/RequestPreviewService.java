package com.printui;

import org.w3c.dom.Document;

public interface RequestPreviewService {

    public Document requestPreview(String auth,String jobid,String mtype,String res); 

}
