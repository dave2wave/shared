package com.printui;

public interface TestService {

    public String testPost(String val); 

}
