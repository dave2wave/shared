package com.printui.api;

import com.printui.AssetActionsService;
import com.printui.api.RequestPreview;
import com.printui.api.RequestPdf;
import com.printui.api.GetPreview;
import com.printui.api.GetPdf;

import javax.jcr.Session;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import java.io.InputStream;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//This is a component so it can provide or consume services
@Component

@Service
public class AssetActions implements AssetActionsService {

    private static final Logger log = LoggerFactory.getLogger(AssetActions.class);

    @Override
    public InputStream requestAndGetPreview(String auth, String job, String resolution, String type) {
	// request printui preview
	RequestPreview requestPreview = new RequestPreview();
	Document doc = requestPreview.requestPreview(auth,job,type,resolution);
	// get results
	Element elem = doc.getDocumentElement();
	NamedNodeMap attrs = elem.getAttributes();
	String loc = attrs.getNamedItem("loc").getNodeValue();
	log.info( "loc: "+loc );
	String t = attrs.getNamedItem("timeout").getNodeValue();
	log.info( "timeout: "+t );
	long timeout = Long.parseLong(t) + 300;
	// get preview stream
	GetPreview getPreview = new GetPreview();
	return getPreview.getPreview(auth,job,loc,timeout);
    }

    @Override
    public InputStream requestAndGetPdf(String auth, String job) {
	// request printui pdf
	RequestPdf requestPdf = new RequestPdf();
	Document doc = requestPdf.requestPdf(auth,job);
	// get results
	Element elem = doc.getDocumentElement();
	NamedNodeMap attrs = elem.getAttributes();
	String loc = attrs.getNamedItem("loc").getNodeValue();
	log.info( "loc: "+loc );
	String t = attrs.getNamedItem("timeout").getNodeValue();
	log.info( "timeout: "+t );
	long timeout = Long.parseLong(t) + 300;
	// get pdf stream
 	GetPdf getPdf = new GetPdf();
	return getPdf.getPdf(auth,job,loc,timeout);
    }

}
