package com.printui.api;

import java.io.InputStream;

import com.printui.impl.PrintUIClientAPI;
import com.printui.PrintUIService;
import com.printui.ClientInfoService;
import com.printui.Configuration;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.client.fluent.Request;
import org.apache.http.HttpResponse;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
public class ClientInfo implements PrintUIService, ClientInfoService {

    private static final Logger log = LoggerFactory.getLogger(ClientInfo.class);

    // Sling Service
    public String getInfo(String val) {
	return getString("auth="+val);
    }

    public Configuration getConfiguration(Configuration c) {
	Document doc = getXML("auth="+c.getAuth());
	try {
	    Element elem = doc.getDocumentElement();
	    c.setClient( elem.getAttribute("c"));
	    c.setAdminUrl( getString("admin_api",elem));
	    c.setIdsUrl( getString("ids_api",elem));
	    String info = "client = "+c.getClient()+", admin = "+c.getAdminUrl()+", ids = "+c.getIdsUrl();
	    log.info(info);
	} catch (Exception e) {
	    log.error("error with post", e);
	}
	return c;
    }

    // PrintUI Service - url hardcoded intentionally
    public InputStream getStream(String params,long timeout) {
	return postForStream("https://admin.w2p-tools.com/api/","getclientinfo.php",params,timeout);
    }

    public Document getXML(String params) {
	return postForXML("https://admin.w2p-tools.com/api/","getclientinfo.php",params);
    }

    public String getString(String params) {
	Document doc = postForXML("https://admin.w2p-tools.com/api/","getclientinfo.php",params);
	String info = "ERROR";
	try {
	    Element elem = doc.getDocumentElement();
	    String admin = getString("admin_api",elem);
	    String ids = getString("ids_api",elem);
	    info = "admin = "+admin+", ids = "+ids;
	    log.info(info);
	} catch (Exception e) {
	    log.error("error with post", e);
	}
	return info;
    }

    public int getStatus(String params) {
	return postForStatus("https://admin.w2p-tools.com/api/","getclientinfo.php",params);
    }
}
