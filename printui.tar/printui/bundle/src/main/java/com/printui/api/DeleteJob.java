package com.printui.api;

import java.io.InputStream;
import com.printui.impl.PrintUIClientAdmin;
import com.printui.PrintUIService;
import com.printui.DeleteJobService;
import com.printui.Configuration;
import com.printui.ConfigurationServiceImpl;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
public class DeleteJob implements PrintUIService, DeleteJobService {

    private static final Logger log = LoggerFactory.getLogger(DeleteJob.class);

    private Configuration cfg;

    // Sling Service
    public boolean deleteJob(String auth,String jobid) {
	cfg = (new ConfigurationServiceImpl()).GetConfiguration(auth);
	int status = getStatus("auth="+auth+"&id="+jobid);
	return (status == 200);
    }

    // PrintUI Service
    public InputStream getStream(String params,long timeout) {
	return postForStream(cfg.getIdsUrl(),"deletejob.php",params,timeout);
    }

    public String getString(String params) {
	return postForString(cfg.getIdsUrl(),"deletejob.php",params);
    }

    public Document getXML(String params) {
	return postForXML(cfg.getIdsUrl(),"deletejob.php",params);
    }

    public int getStatus(String params) {
	return postForStatus(cfg.getIdsUrl(),"deletejob.php",params);
    }
}
