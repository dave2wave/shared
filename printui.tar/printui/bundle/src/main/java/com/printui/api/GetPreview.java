package com.printui.api;

import java.io.InputStream;
import com.printui.impl.PrintUIClientAdmin;
import com.printui.PrintUIService;
import com.printui.GetPreviewService;
import com.printui.Configuration;
import com.printui.ConfigurationServiceImpl;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
public class GetPreview implements PrintUIService, GetPreviewService {

    private static final Logger log = LoggerFactory.getLogger(GetPreview.class);

    private Configuration cfg;

    // Sling Service
    public InputStream getPreview(String auth,String jobid,String loc,long timeout) {
	cfg = (new ConfigurationServiceImpl()).GetConfiguration(auth);
	return getStream("auth="+auth+"&id="+jobid+"&loc="+loc,timeout);
    }

    // PrintUI Service
    public InputStream getStream(String params,long timeout) {
	return postForStream(cfg.getIdsUrl(),"getpreview.php",params,timeout);
    }

    public String getString(String params) {
	return postForString(cfg.getIdsUrl(),"getpreview.php",params);
    }

    public Document getXML(String params) {
	return postForXML(cfg.getIdsUrl(),"getpreview.php",params);
    }

    public int getStatus(String params) {
	return postForStatus(cfg.getIdsUrl(),"getpreview.php",params);
    }
}
