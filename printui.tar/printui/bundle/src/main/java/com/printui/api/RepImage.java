package com.printui.api;

import java.io.InputStream;
import java.lang.System;

import com.printui.impl.PrintUIClientAPI;
import com.printui.PrintUIService;
import com.printui.RepImageService;
import com.printui.Configuration;
import com.printui.ConfigurationServiceImpl;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.client.fluent.Request;
import org.apache.http.HttpResponse;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
public class RepImage implements PrintUIService, RepImageService {

    private static final Logger log = LoggerFactory.getLogger(RepImage.class);

    private Configuration cfg;
    
    // Sling Service
    public String getThumbnail(String auth, String t, String n) {
	cfg = (new ConfigurationServiceImpl()).GetConfiguration(auth);
	return getString("auth="+auth+"&t="+t+"&n="+n);
    }

    // PrintUI Service
    public InputStream getStream(String params,long timeout) {
	return postForStream(cfg.getIdsUrl(),"repimage.php",params,timeout);
    }

    public Document getXML(String params) {
	return postForXML(cfg.getIdsUrl(),"repimage.php",params);
    }

    public String getString(String params) {
	Document doc = postForXML(cfg.getIdsUrl(),"repimage.php",params);
	String info = "ERROR";
	try {
	    Element elem = doc.getDocumentElement();
	    info = getString("url",elem);
	    log.info(info);
	} catch (Exception e) {
	    log.error("error with post", e);
	}
	return info;
    }

    public int getStatus(String params) {
	return postForStatus(cfg.getIdsUrl(),"repimage.php",params);
    }
}
