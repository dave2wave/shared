package com.printui.impl;

import com.printui.AssetService;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.DOMException;

import com.day.cq.search.QueryBuilder; 
import com.day.cq.search.Query; 
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.result.SearchResult;
import com.day.cq.search.result.Hit;

import com.adobe.granite.asset.api.AssetManager;
import com.adobe.granite.asset.api.Asset;
import com.adobe.granite.asset.api.Rendition;

import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.jcr.JsonItemWriter;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Session;
import javax.jcr.RepositoryException;
import javax.jcr.PathNotFoundException;

import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import java.io.StringWriter;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * One implementation of the {@link AssetService}. Note that
 * the repository is injected, not retrieved.
 */
@Service
@Component(metatype = false)
public class AssetServiceImpl implements AssetService {

    private static final Logger log = LoggerFactory.getLogger(AssetServiceImpl.class);

    private Session session;

    private Query q;
    private SearchResult sr;
    private long total;
    private List<Hit> results;
    private boolean isCollection;
    private boolean isFullText;
    private ResourceResolver resourceResolver;
    private QueryBuilder builder;
    private AssetManager dam;

    @Override
    public long execute(final ResourceResolver resolver,
			final String path,
			final String query,
			int offset, int size) {
	log.info("Asset Query for "+path);
	resourceResolver = resolver;
	session = resourceResolver.adaptTo(Session.class);
	builder = resourceResolver.adaptTo(QueryBuilder.class);
	dam = resourceResolver.adaptTo(AssetManager.class);
	isCollection = path.startsWith("/content/dam/collections");
	isFullText = !"".equals(query);
	Map<String, String> map = new HashMap<String, String>();
        map.put("path", path);
	if ( isFullText ) {
	    map.put("fulltext", query);
	}
	if ( isCollection ) {
	    map.put("property","@sling:resource");
	    map.put("property.operation","exists");
	    map.put("orderby","@sling:resource");
	} else {
	    map.put("type", "dam:Asset");
	    map.put("orderby","@jcr:content/jcr:lastModified");
	    map.put("orderby.sort","desc");
	    map.put("property","jcr:content/metadata/dc:format");
	    // replace with mimetypes
	    map.put("property.1_value","image/png");
	    map.put("property.2_value","image/jpeg");
	    map.put("property.3_value","application/pdf");
	    map.put("hits","full");
	    map.put("nodedepth","10");
	}
	map.put("p.offset",Integer.toString(offset));
	map.put("p.limit",Integer.toString(size));
	q = builder.createQuery(PredicateGroup.create(map), session);
	sr = q.getResult();
	total = sr.getTotalMatches();
	results = sr.getHits();
	log.info("Query results = "+total);
	return total;
    }

    public HashMap[] getResults(int offset, int size) {
	try {
	    long count = size;
	    if ( total < offset ) return null;
	    if ( count > (total-offset) ) count = total-offset;
	    log.info("offset="+offset+"; count="+count);
	    List<Map<String,String>> list = new ArrayList<Map<String,String>>();
	    for ( int i=0; i<count; i++) {
		String path = results.get(i).getPath();
		String parent = path.substring(0,path.lastIndexOf("/"));
		if ( isCollection ) {
		    ValueMap map = results.get(i).getProperties();
		    path = map.get("sling:resource",String.class);
		    parent = parent.substring(0,parent.lastIndexOf("/"));
		}
		if ( dam.assetExists(path) ) {
		    Map<String,String> data = new HashMap<String,String>();
		    data.put("url",path);
		    data.put("folder",parent);
		    Asset asset = dam.getAsset(path);
		    Node jcr = session.getNode(path+"/jcr:content");
		    Node meta = session.getNode(path+"/jcr:content/metadata");
		    String title = "missing";
		    try {
			title = meta.getProperty("dc:title").getString();
		    } catch(PathNotFoundException e) {
			log.error(path+" missing dc:title");
		    }
		    data.put("name",title);
		    String type = "missing";
		    try {
			type = meta.getProperty("dc:format").getString();
		    } catch(PathNotFoundException e) {
			log.error(path+" missing dc:format");
		    }
		    data.put("mimetype",type);
		    String modified = "missing";
		    try {
			modified = jcr.getProperty("jcr:lastModified").getString();
		    } catch(PathNotFoundException e) {
			log.error(path+" missing jcr:lastModified");
		    }			
		    data.put("modified_at",modified);
		    Rendition rendition = asset.getRendition("cq5dam.thumbnail.48.48.png");
		    boolean thumbnail = (rendition!=null);
		    data.put("thumbnailed",(thumbnail?"true":"false"));
		    if ( thumbnail ) {
			String thumbnail_url = path+"/jcr:content/renditions/cq5dam.thumbnail.48.48.png";
			data.put("thumbnail_url",thumbnail_url);
		    }
		    if ( offset == 0 && size == 1 ) {
			Rendition original = asset.getRendition("original");
			if ( original!=null ) {
			    data.put("filesize",String.valueOf(original.getSize()));
			}
		    }
		    log.debug(i+" Asset parent="+parent+" path="+path+" title="+title+" type="+type+" modified="+modified+" thumbnail="+thumbnail);
		    list.add(data);
		} else {
		    log.error(i+" Asset Missing="+path);
		}
	    }
	    return list.toArray(new HashMap[list.size()]);
	} catch (RepositoryException e) {
	    log.error("Exception",e);
	}
    	return null;
    }

    @Override
    public JSONObject getResultsAsJSON(int offset, int size) {
	HashMap[] maps = getResults(offset,size);
	if (maps == null) return null;
	JSONObject jsonObject = new JSONObject();
	try {
	    jsonObject = jsonObject.put("count",maps.length);
	    jsonObject = jsonObject.put("offset",offset);
	    jsonObject = jsonObject.put("size",size);
	    jsonObject = jsonObject.put("total",total);
	    for ( HashMap map : maps ) {
		String url = (String)map.get("url");
		jsonObject = jsonObject.put(url,map);
	    }
	} catch(JSONException | NullPointerException e) {
	    log.error("Could not create JSON", e);
	}
    	return jsonObject;
    }

    @Override
    public Document getResultsAsXML(int offset, int size) {
	Map[] maps = getResults(offset,size);
    	return null;
    }

    @Override
    public JSONObject create(final ResourceResolver resolver,
			     final String path,
			     final String filename,
			     final String mimetype,
			     final String collection,
			     final String version,
			     InputStream stream) {
	log.info("Create Asset "+path+"/"+filename);
	resourceResolver = resolver;
	session = resourceResolver.adaptTo(Session.class);
	dam = resourceResolver.adaptTo(AssetManager.class);
	if ( !"".equals(collection) ) {
	    isCollection = collection.startsWith("/content/dam/collections");
	} else {
	    isCollection = false;
	}
	Map<String, String> map = new HashMap<String, String>();
	JSONObject jsonObject = new JSONObject();
	try {
	    jsonObject = jsonObject.put("results",map);
	} catch (JSONException e) {
	    log.error("Error building results object",e);
	}
    	return jsonObject;
    }

    @Override
    public JSONObject newFolder(final ResourceResolver resolver,
				final String path,
				final String foldername) {
	log.info("New Folder "+path+"/"+foldername);
	resourceResolver = resolver;
	session = resourceResolver.adaptTo(Session.class);
	Map<String, String> map = new HashMap<String, String>();
	String resPath = path+"/"+foldername;
	Resource parent = resourceResolver.getResource(path);
	Resource resource = resourceResolver.getResource(resPath);
	if ( parent ==  null ) {
	    map.put("error","path "+path+" does not exist");
	} else if ( path.startsWith("/content/dam/collections") ) {
	    map.put("error","AEM does not support adding folders to a collection");
	} else if ( !resourceResolver.isResourceType(parent,"sling:Folder") && !resourceResolver.isResourceType(parent,"sling:OrderedFolder")) {
	    map.put("error","path "+path+" is not a folder");
	} else if ( resource != null ) {
	    if ( !resourceResolver.isResourceType(resource,"sling:Folder") && !resourceResolver.isResourceType(resource,"sling:OrderedFolder")) {
		map.put("error","folder "+foldername+" exists and is not a folder");
	    } else {
		map.put("warning","folder "+foldername+" already exists");
	    }
	} else {
	    Map<String, Object> props = new HashMap<String, Object>();
	    props.put("jcr:primaryType","sling:OrderedFolder");
	    try {
		resource = resourceResolver.create(parent,foldername,props);
		resourceResolver.commit();
		map.put("new-folder",foldername);
	    } catch (Exception e) {
		log.error("Error creating folder: "+resPath, e);
		map.put("error",e.getMessage());
	    }
	}
	JSONObject jsonObject = new JSONObject();
	try {
	    jsonObject = jsonObject.put("results",map);
	    log.info(jsonObject.toString(4));
	} catch (JSONException e) {
	    log.error("Error building results object",e);
	}
    	return jsonObject;
    }
}
