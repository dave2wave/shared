package com.printui.impl;

import com.printui.DataService;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.DOMException;

import com.adobe.granite.rest.utils.DeepModifiableValueMapDecorator;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.jcr.JsonItemWriter;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.jcr.RepositoryException;

import java.util.concurrent.ConcurrentHashMap;

import java.io.StringWriter;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * One implementation of the {@link DataService}. Note that
 * the repository is injected, not retrieved.
 */
@Service
@Component(metatype = false)
public class DataServiceImpl implements DataService {

    private static final Logger log = LoggerFactory.getLogger(DataServiceImpl.class);

    public DeepModifiableValueMapDecorator getData(final ResourceResolver resourceResolver, final String path) {
	log.info("MVM for "+path);
	ConcurrentHashMap<String,Object> base = new ConcurrentHashMap<String,Object>();
	final Resource resource = resourceResolver.getResource(path);
	DeepModifiableValueMapDecorator mvm = new DeepModifiableValueMapDecorator(resource,base);
	return mvm;
    }

    public JSONObject getDataAsJSON(final ResourceResolver resourceResolver, final String path) {
	log.info("JSON for "+path);
        JSONObject jsonObject = null;
	try {
	    final Resource resource = resourceResolver.getResource(path);
	    final Node node = resource.adaptTo(Node.class);
	    final StringWriter stringWriter = new StringWriter();
	    final JsonItemWriter jsonWriter = new JsonItemWriter(null);
	    // recursion
            jsonWriter.dump(node, stringWriter, -1);
            jsonObject = new JSONObject(stringWriter.toString());
        } catch (RepositoryException | JSONException e) {
            log.error("Could not create JSON", e);
        }
        return jsonObject;
    }

    public Document getDataAsXML(final ResourceResolver resourceResolver, final String path) {
	log.info("XML for "+path);
	Document doc = null;
	try {
	    final Session session = resourceResolver.adaptTo(Session.class);
	    final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    final DocumentBuilder builder = factory.newDocumentBuilder();
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    // no binary, recursion
	    session.exportDocumentView(path, out, true, false);
	    ByteArrayInputStream in = new ByteArrayInputStream( out.toByteArray() );
	    out.close();
	    doc = builder.parse( in );
	    in.close();
	    Element element = doc.getDocumentElement();
	    log.info("root="+element.getTagName());
	} catch (IOException | ParserConfigurationException | RepositoryException | DOMException | SAXException e) {
            log.error("Could not create XML", e);
	}
	return doc;
    }

}
