/*
 * #%L
 * ACS AEM Commons Bundle
 * %%
 * Copyright (C) 2016 Adobe
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
/**
From package com.adobe.acs.commons.http.impl;
*/
package com.printui.impl;

import com.printui.PrintUIClientFactory;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.fluent.Executor;
import org.apache.http.client.fluent.Request;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

public class PrintUIClientAdmin implements PrintUIClientFactory {

    private static final Logger log = LoggerFactory.getLogger(PrintUIClientAdmin.class);

    public static final boolean DEFAULT_USE_SSL = true;

    public static final boolean DEFAULT_DISABLE_CERT_CHECK = false;

    public static final int DEFAULT_CONNECT_TIMEOUT = 30000;

    public static final int DEFAULT_SOCKET_TIMEOUT = 30000;

    public static final String SERVICE = "printui-admin";

    private Executor executor;
    private String baseUrl;
    private CloseableHttpClient httpClient;

    public void activate() throws Exception {
        boolean useSSL = DEFAULT_USE_SSL;

        String scheme = useSSL ? "https" : "http";
        String hostname = "admin.w2p-tools.com";
        int port = 443;

        if (hostname == null || port == 0) {
            throw new IllegalArgumentException("Configuration not valid. Both host and port must be provided.");
        }

        baseUrl = String.format("%s://%s:%s", scheme, hostname, port);
	log.info(baseUrl);

        int connectTimeout = DEFAULT_CONNECT_TIMEOUT;
        int soTimeout = DEFAULT_SOCKET_TIMEOUT;

        //RequestConfig requestConfig = RequestConfig.custom()
        //        .setConnectTimeout(connectTimeout)
        //        .setSocketTimeout(soTimeout)
        //        .build();
        //builder.setDefaultRequestConfig(requestConfig);

        boolean disableCertCheck = DEFAULT_DISABLE_CERT_CHECK;

        //if (useSSL && disableCertCheck) {
            // Disable hostname verification and allow self-signed certificates
	//  SSLContextBuilder sslbuilder = new SSLContextBuilder();
        //    sslbuilder.loadTrustMaterial(new TrustSelfSignedStrategy());
        //    SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
        //            sslbuilder.build(), NoopHostnameVerifier.INSTANCE);
        //    builder.setSSLSocketFactory(sslsf);
        //}
        httpClient = HttpClientBuilder.create().build();//.setDefaultRequestConfig(requestConfig);
        executor = Executor.newInstance(httpClient);
    }

    public void deactivate() {
        if (httpClient != null) {
            try {
                httpClient.close();
            } catch (final IOException e) {
                // do nothing
            }
        }
    }

    @Override
    public Executor getExecutor() {
        return executor;
    }

    @Override
    public Request get(String partialUrl) {
        String url = baseUrl + partialUrl;
        return Request.Get(url);
    }

    @Override
    public Request post(String partialUrl) {
        String url = baseUrl + partialUrl;
        return Request.Post(url);
    }

    @Override
    public Request put(String partialUrl) {
        String url = baseUrl + partialUrl;
        return Request.Put(url);
    }

    @Override
    public Request delete(String partialUrl) {
        String url = baseUrl + partialUrl;
        return Request.Delete(url);
    }

    @Override
    public Request options(String partialUrl) {
        String url = baseUrl + partialUrl;
        return Request.Options(url);
    }

}
