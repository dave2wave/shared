package com.printui.impl;

import com.printui.TestService;
import com.printui.api.ClientInfo;
import com.printui.api.ListTemplates;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
//This is a component so it can provide or consume services
@Component
  
@Service
public class TestServiceImpl implements TestService {

    private static final Logger log = LoggerFactory.getLogger(TestServiceImpl.class);

    @Override
    public String testPost(String val) {
	//GetClientInfo request = new GetClientInfo();
	//return request.post(val);
	log.info("test="+val);
	//return val+val;
	//String result = (new ClientInfo()).getString(val);
	String result = (new ListTemplates()).getString(val);
	log.info("result="+result);
	return result;
    }
}
