package com.printui.servlet;

import com.printui.impl.AssetServiceImpl;
import com.printui.ConfigurationServiceImpl;
import com.printui.Configuration;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.CharEncoding;

import org.apache.sling.commons.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.rmi.ServerException;
import java.lang.NullPointerException;
 
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.osgi.service.component.ComponentContext;
import org.osgi.framework.Constants;
import javax.jcr.Session;
import javax.jcr.Node;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
   
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Iterator;
import java.util.List;
import java.io.OutputStream;
import java.io.PrintWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
    
import java.io.StringWriter;
  
import javax.jcr.Repository;
import javax.jcr.SimpleCredentials;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
     
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
    
import javax.jcr.Session;
import javax.jcr.Node;
  
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory ;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
 
//This is a component so it can provide or consume services
@SlingServlet(paths="/bin/linkrui/asset-detail", methods = "POST", metatype=false)
public class AssetDetailServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
    private static final long serialVersionUID = 2598436539996787515L;

    protected final Logger log = LoggerFactory.getLogger(AssetDetailServlet.class);
    
    private Session session;

    //Inject a Sling ResourceResolverFactory
    @Reference
    private ResourceResolverFactory resolverFactory;
       
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {

    }
       
       
    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
	String auth = request.getParameter("auth");
	String path = request.getParameter("path_id");
	int i = path.lastIndexOf("/");
	String query = path.substring(i);
	path = path.substring(0,i);
	int limit = 1;
	int offset = 0;

	try {
	    ResourceResolver resourceResolver = request.getResourceResolver();

	    //ConfigurationServiceImpl cs = new ConfigurationServiceImpl();
	    //Configuration cfg = cs.GetConfiguration("7564bd5a");

	    AssetServiceImpl q = new AssetServiceImpl();
	    long count = q.execute(resourceResolver,path,query, offset, limit );
	    JSONObject json = q.getResultsAsJSON(offset, limit);
	    response.setCharacterEncoding("utf-8");
	    response.setStatus(200);
	    response.setContentType("application/json;charset=utf-8");
	    PrintWriter respond = response.getWriter();
	    respond.print(json.toString(4));
	    respond.flush();
	} catch (NullPointerException e ) {
	    // means the asset was missing
	    response.setStatus(404);
	} catch (Exception e ) {
	    response.setStatus(403);
	    log.error("error with post:", e);
	}
    }
   
}
